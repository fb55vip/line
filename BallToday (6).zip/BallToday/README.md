# BallToday

เว็บไซต์ฟุตบอลแบบ Static Site ธีม Premium Dark Sports รองรับ Responsive และวางพื้นฐาน SEO ครบทุกหน้า

## เปิดใช้งาน
เปิด `index.html` หรือใช้ VS Code Live Server

## เชื่อม Football API
แก้ค่า `API_CONFIG` ใน `assets/js/app.js` และแทน `demoMatches` ด้วยการเรียก API ผ่าน backend/serverless function เพื่อไม่เปิดเผย API key ฝั่ง browser

## ก่อนขึ้นเว็บไซต์จริง
แทน `https://balltoday.example` ในทุกไฟล์ด้วยโดเมนจริง แล้วปรับ `robots.txt`, `sitemap.xml`, Open Graph image และข้อมูล JSON-LD
