const API_CONFIG = { provider: 'YOUR_PROVIDER', baseUrl: '', apiKey: '' };
const demoMatches = [
 {time:'19:30',league:'Premier League',home:'Manchester City',away:'Liverpool',score:'–'},
 {time:'21:00',league:'La Liga',home:'Real Madrid',away:'Barcelona',score:'–'},
 {time:'LIVE',league:'Thai League',home:'Buriram United',away:'BG Pathum',score:'1 - 0'}
];
function renderMatches(items=demoMatches){const root=document.querySelector('[data-match-list]');if(!root)return;root.innerHTML=items.map(m=>`<article class="match"><time>${m.time}</time><div class="home"><b>${m.home}</b><div class="league">${m.league}</div></div><div class="status">${m.score}</div><div class="away"><b>${m.away}</b><div class="league">${m.league}</div></div><span class="badge">รายละเอียด</span></article>`).join('')}
function initMenu(){const btn=document.querySelector('.menu-btn'),nav=document.querySelector('.nav-links');btn?.addEventListener('click',()=>{const open=nav.classList.toggle('open');btn.setAttribute('aria-expanded',String(open))})}
function initSearch(){const form=document.querySelector('[data-search-form]');form?.addEventListener('submit',e=>{e.preventDefault();const q=new FormData(form).get('q')?.toString().trim();if(q)location.href=`${form.dataset.base||''}pages/results/?q=${encodeURIComponent(q)}`})}
document.addEventListener('DOMContentLoaded',()=>{initMenu();initSearch();setTimeout(()=>renderMatches(),450)})
